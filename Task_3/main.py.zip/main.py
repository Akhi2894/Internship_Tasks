#Q1
import re

from solutions import word_frequency
import solutions
sentence = "python is easy and python is powerful"
result = word_frequency(sentence)
print(result)

#Q2
from solutions import character_frequency
word = "banana"
result = (character_frequency(word))
print(result)

#Q3
from solutions import first_non_repeating_character
word = "swiss"
result = (first_non_repeating_character(word))
print(result)

#Q4
from solutions import check_anagram
s1 = "listen"
s2 = "silent"
if check_anagram(s1,s2):
    print("the string are anagrams")
else:
    print("the strings are not anagrams")


#Q5
from solutions import first_repeating_char
s = "programming"
result = first_repeating_char(s)
print("first repeating character:", result)

#Q6
from solutions import move_zeros
L = [0,3,0,1,2,0,4]
result = move_zeros
print(result)


#Q7
from solutions import second_highest
L  = [10,20,40,30,40,20]
result = second_highest(L)
print("second highest number is:", result)

#Q8
from solutions import remove_duplicates
L= [4,2,4,5,2,7,5]
result = remove_duplicates(L)
print("list after removing duplicates:", result)

#Q9
from solutions import find_missing_number
nums = [1,2,4,5,6]
N = 6
result = find_missing_number(nums, N)   
print("missing number is:", result)


#Q10
from solutions import find_two_numbers_with_sum
nums = [2,7,11,15]
target = 9
result = find_two_numbers_with_sum(nums, target)
print("two numbers with sum", target, "are:", result)

#Q11
from solutions import find_closest_to_zero
nums = [8, -3, 2, 5, -2]
result = find_closest_to_zero(nums)
print("number closest to zero is:", result)

#Q12
from solutions import find_common_elements
list1 = [1, 2, 3, 4, 5]
list2 = [3, 4, 5, 6, 7]
result = find_common_elements(list1, list2)
print("common elements are:", result)


#Q13
from solutions import rotate_list
nums = [1, 2, 3, 4, 5]
k = 2
result = rotate_list(nums, k)
print("list after rotating to the right by", k, "positions:", result)


#Q14
from solutions import max_sum_of_consecutive_elements
nums = [4, 7, 2, 9, 5]
result = max_sum_of_consecutive_elements(nums)
print("maximum sum of two consecutive elements is:", result)

#Q15
from solutions import find_all_pairs_with_sum
nums = [2, 4, 3, 5, 7, 8, 1]
target = 9
result = find_all_pairs_with_sum(nums, target)
