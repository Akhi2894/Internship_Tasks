
#Q1
from turtle import st


def word_frequency(sentence):
    words = sentence.split()
    frequency ={}

    for word in words:
        if word in frequency:
            frequency[word] += 1
        else:
            frequency[word] = 1
    return frequency

#Q2:Find the Frequency of Each Character in a Word
def character_frequency(word):
    frequency = {}
    for char in word:
        if char in frequency:
            frequency[char] += 1
        else:
            frequency[char] = 1
    return frequency


#Q3:Find the First Non-Repeating Character in a Word
def first_non_repeating_character(word):
    frequency = character_frequency(word)
    for char in word:
        if frequency[char] == 1:
            return char
    return None


#Q4:Check Whether Two Strings Are Anagrams
def check_anagram(s1,s2):
    if sorted(s1) == sorted(s2):
        return True
    else:
        return False



#Q5:Find the First Repeating Character in a String
def first_repeating_char(s):
    seen = set()
    for ch in s:
        if ch in seen:
            return ch
        seen.add(ch)
    return -1


#Q6:Move All Zeros to the End of a List
def move_zeros(lst):
    result = []

    for num in lst:
        if num != 0:
            result.append(num)
    zeros = lst.count(0)
    result.extend([0] * zeros)
    return result


#Q7:Find the Second Highest Distinct Number in a List
def second_highest(lst):
    unique_numbers = list(set(lst))
    unique_numbers.sort(reverse=True)
    if len(unique_numbers) >= 2:
        return unique_numbers[1]
    else:
        return None

#Q8:Remove Duplicates Without Changing the Original Order
def remove_duplicates(lst):
    seen = set()
    result = []
    for item in lst:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result

#Q9:Find the Missing Number from 1 to N
def find_missing_number(lst, N):
    expected_sum = N * (N + 1) // 2
    actual_sum = sum(lst)
    return expected_sum - actual_sum

#Q10: Find Two Numbers Whose Sum Equals a Target
def find_two_numbers_with_sum(lst, target):
    seen = set()
    for num in lst:
        complement = target - num
        if complement in seen:
            return (complement, num)
        seen.add(num)
    return None

#Q11:Find the Number Closest to Zero
def find_closest_to_zero(lst):
    if not lst:
        return None
    closest = lst[0]
    for num in lst:
        if abs(num) < abs(closest) or (abs(num) == abs(closest) and num > closest):
            closest = num
    return closest

#Q12:Find Common Elements Between Two Lists
def find_common_elements(lst1, lst2):
    return list(set(lst1) & set(lst2))

#Q13:Rotate a List to the Right by K Positions
def rotate_list(lst, k):
    n = len(lst)
    k = k % n  # Handle cases where k is greater than the length of the list
    return lst[-k:] + lst[:-k]  

#Q14:Find the Maximum Sum of Two Consecutive Elements
def max_sum_of_consecutive_elements(lst):
    if len(lst) < 2:
        return None
    max_sum = lst[0] + lst[1]
    for i in range(1, len(lst) - 1):
        current_sum = lst[i] + lst[i + 1]
        if current_sum > max_sum:
            max_sum = current_sum
    return max_sum

#Q15:Find All Pairs of Numbers Whose Sum Equals a Target
def find_all_pairs_with_sum(lst, target):
    pairs = []
    seen = set()
    for num in lst:
        complement = target - num
        if complement in seen:
            pairs.append((complement, num))
        seen.add(num)
    return pairs